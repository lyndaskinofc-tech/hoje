<?php
require_once 'config/config.php';
require_once 'classes/User.php';

if (is_logged_in()) {
    redirect(BASE_URL . 'dashboard.php');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if (empty($username) || empty($password)) {
        $error = 'Por favor, preencha todos os campos.';
    } else {
        $conn = db_connect();
        $user = new User($conn);
        
        if ($user->authenticate($username, $password)) {
            redirect(BASE_URL . 'dashboard.php');
        } else {
            $error = 'Usuário ou senha incorretos.';
        }
        
        db_close($conn);
    }
}

$page_title = 'Login';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - Diamond System</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="<?php echo BASE_URL; ?>assets/css/style.css" rel="stylesheet">
    
    <style>
        .login-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow: hidden;
            padding: 20px;
        }
        
        .login-bg-shape {
            position: absolute;
            border-radius: 50%;
            filter: blur(120px);
            opacity: 0.3;
            animation: float 20s ease-in-out infinite;
        }
        
        .shape-1 {
            width: 600px;
            height: 600px;
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            top: -200px;
            right: -200px;
        }
        
        .shape-2 {
            width: 400px;
            height: 400px;
            background: linear-gradient(135deg, #10b981, #06b6d4);
            bottom: -100px;
            left: -100px;
        }
        
        @keyframes float {
            0%, 100% { transform: translate(0, 0) scale(1); }
            25% { transform: translate(50px, -50px) scale(1.1); }
            50% { transform: translate(-30px, 30px) scale(0.9); }
            75% { transform: translate(40px, 40px) scale(1.05); }
        }
        
        .login-card {
            position: relative;
            z-index: 10;
            width: 100%;
            max-width: 450px;
            background: rgba(10, 15, 26, 0.9) !important;
            backdrop-filter: blur(40px) saturate(180%);
            border: 1px solid rgba(59, 130, 246, 0.3) !important;
            border-radius: 24px !important;
            box-shadow: 0 20px 80px rgba(0, 0, 0, 0.5), 0 0 60px rgba(59, 130, 246, 0.2) !important;
            overflow: hidden;
            animation: slideUp 0.6s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        @keyframes slideUp {
            from { opacity: 0; transform: translateY(40px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .login-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 2px;
            background: linear-gradient(90deg, transparent, #3b82f6, #8b5cf6, transparent);
            animation: shimmerTop 3s linear infinite;
        }
        
        @keyframes shimmerTop {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(100%); }
        }
        
        .login-header {
            text-align: center;
            padding: 40px 32px 28px;
            background: linear-gradient(180deg, rgba(59, 130, 246, 0.08), transparent);
            border-bottom: 1px solid rgba(59, 130, 246, 0.1);
        }
        
        .login-logo {
            width: 70px;
            height: 70px;
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            border-radius: 18px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            color: white;
            margin-bottom: 20px;
            position: relative;
            animation: pulse-icon 3s ease-in-out infinite;
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
        }
        
        @keyframes pulse-icon {
            0%, 100% {
                box-shadow: 0 0 0 0 rgba(59, 130, 246, 0.7), 0 4px 12px rgba(59, 130, 246, 0.3);
            }
            50% {
                box-shadow: 0 0 0 25px rgba(59, 130, 246, 0), 0 4px 12px rgba(59, 130, 246, 0.3);
            }
        }
        
        .login-logo::before {
            content: '';
            position: absolute;
            inset: -3px;
            border-radius: 20px;
            padding: 3px;
            background: linear-gradient(135deg, rgba(59, 130, 246, 0.6), rgba(139, 92, 246, 0.6));
            -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
            -webkit-mask-composite: xor;
            mask-composite: exclude;
            animation: rotate-border 4s linear infinite;
        }
        
        @keyframes rotate-border {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .login-logo::after {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255, 255, 255, 0.1) 0%, transparent 70%);
            animation: rotate-glow 8s linear infinite;
        }
        
        @keyframes rotate-glow {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .login-title {
            font-size: 26px;
            font-weight: 900;
            background: linear-gradient(135deg, #60a5fa, #a78bfa);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 6px;
        }
        
        .login-subtitle {
            color: var(--muted-text);
            font-size: 14px;
        }
        
        .login-body {
            padding: 32px;
        }
        
        .login-input-group {
            position: relative;
            margin-bottom: 20px;
        }
        
        .login-input-icon {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            color: #60a5fa;
            font-size: 18px;
            z-index: 2;
        }
        
        .login-input {
            width: 100%;
            padding: 13px 18px 13px 48px !important;
            background: rgba(59, 130, 246, 0.05) !important;
            border: 2px solid rgba(59, 130, 246, 0.2) !important;
            border-radius: 12px !important;
            color: var(--white-text) !important;
            font-size: 15px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .login-input:focus {
            background: rgba(59, 130, 246, 0.08) !important;
            border-color: #3b82f6 !important;
            box-shadow: 0 0 0 4px rgba(59, 130, 246, 0.15) !important;
            transform: translateY(-2px);
        }
        
        .login-btn {
            width: 100%;
            padding: 14px !important;
            background: linear-gradient(135deg, #3b82f6, #8b5cf6) !important;
            border: none !important;
            border-radius: 12px !important;
            color: white !important;
            font-size: 15px !important;
            font-weight: 700 !important;
            text-transform: uppercase;
            letter-spacing: 1px;
            position: relative;
            overflow: hidden;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .login-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 40px rgba(59, 130, 246, 0.4);
        }
        
        .login-footer {
            text-align: center;
            padding-top: 16px;
            margin-top: 16px;
            border-top: 1px solid rgba(59, 130, 246, 0.1);
        }
        
        .login-footer a {
            color: #60a5fa !important;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .login-footer a:hover {
            color: #3b82f6 !important;
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-bg-shape shape-1"></div>
        <div class="login-bg-shape shape-2"></div>
        
        <div class="login-card">
            <div class="login-header">
                <div class="login-logo">
                    <i class="fas fa-gem"></i>
                </div>
                <h1 class="login-title">Diamond System</h1>
                <p class="login-subtitle">Faça login para continuar</p>
            </div>
            
            <div class="login-body">
                <?php if ($error): ?>
                    <div class="alert alert-danger mb-3">
                        <i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?>
                    </div>
                <?php endif; ?>
                
                <form method="post">
                    <div class="login-input-group">
                        <i class="fas fa-user login-input-icon"></i>
                        <input type="text" class="login-input" name="username" placeholder="Usuário" required autofocus>
                    </div>
                    
                    <div class="login-input-group">
                        <i class="fas fa-lock login-input-icon"></i>
                        <input type="password" class="login-input" id="password-input" name="password" placeholder="Senha" required style="padding-right: 48px !important;">
                        <button type="button" class="toggle-password" onclick="togglePasswordVisibility()" style="position: absolute; right: 16px; top: 50%; transform: translateY(-50%); background: none; border: none; color: #60a5fa; cursor: pointer; z-index: 2; font-size: 18px; padding: 0; width: 24px; height: 24px; transition: all 0.3s ease;">
                            <i class="fas fa-eye" id="toggle-password-icon"></i>
                        </button>
                    </div>
                    
                    <button type="submit" class="login-btn">
                        <span style="position: relative; z-index: 1;">
                            <i class="fas fa-sign-in-alt me-2"></i>Entrar
                        </span>
                    </button>
                    
                    <div class="login-footer">
                        <a href="forgot_password.php">
                            <i class="fas fa-key me-1"></i>Esqueceu sua senha?
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function togglePasswordVisibility() {
            const passwordInput = document.getElementById('password-input');
            const toggleIcon = document.getElementById('toggle-password-icon');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleIcon.classList.remove('fa-eye');
                toggleIcon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                toggleIcon.classList.remove('fa-eye-slash');
                toggleIcon.classList.add('fa-eye');
            }
        }
    </script>
</body>
</html>
