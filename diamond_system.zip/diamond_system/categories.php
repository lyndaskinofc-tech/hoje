<?php
require_once 'config/config.php';
require_once 'classes/Category.php';

check_permission(['admin', 'manager']);

$conn = db_connect();
$category = new Category($conn);

$action = $_GET['action'] ?? 'list';
$id = $_GET['id'] ?? 0;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'] ?? '';
    $description = $_POST['description'] ?? '';
    
    if ($action == 'create') {
        if ($category->create($name, $description)) {
            display_success('Categoria cadastrada com sucesso!');
            redirect(BASE_URL . 'categories.php');
        } else {
            display_error('Erro ao cadastrar categoria.');
        }
    } elseif ($action == 'edit' && $id > 0) {
        if ($category->update($id, $name, $description)) {
            display_success('Categoria atualizada com sucesso!');
            redirect(BASE_URL . 'categories.php');
        } else {
            display_error('Erro ao atualizar categoria.');
        }
    }
}

if ($action == 'delete' && $id > 0) {
    if ($category->delete($id)) {
        display_success('Categoria excluída com sucesso!');
    } else {
        display_error('Não é possível excluir uma categoria com produtos.');
    }
    redirect(BASE_URL . 'categories.php');
}

$categories = $category->getAllWithProductCount();
$page_title = 'Categorias';

require_once 'includes/header.php';
require_once 'includes/sidebar.php';
?>

<?php if ($action == 'list'): ?>
<div class="d-flex justify-content-between flex-wrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><i class="fas fa-tags me-2"></i>Gerenciar Categorias</h1>
    <div class="btn-toolbar mb-2">
        <a href="?action=create" class="btn btn-primary">
            <i class="fas fa-plus me-1"></i> Nova Categoria
        </a>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>Descrição</th>
                        <th>Produtos</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($categories as $cat): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($cat['name']); ?></td>
                        <td><?php echo htmlspecialchars($cat['description']); ?></td>
                        <td><span class="badge bg-info"><?php echo $cat['product_count']; ?> produtos</span></td>
                        <td>
                            <a href="?action=edit&id=<?php echo $cat['id']; ?>" class="btn btn-sm btn-outline-primary">
                                <i class="fas fa-edit"></i>
                            </a>
                            <a href="?action=delete&id=<?php echo $cat['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Tem certeza que deseja excluir esta categoria?')">
                                <i class="fas fa-trash"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php elseif ($action == 'create' || $action == 'edit'): ?>
<?php
$current_category = null;
if ($action == 'edit' && $id > 0) {
    $current_category = $category->getById($id);
    if (!$current_category) {
        display_error('Categoria não encontrada.');
        redirect(BASE_URL . 'categories.php');
    }
}
?>

<div class="d-flex justify-content-between flex-wrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><?php echo $action == 'create' ? 'Nova Categoria' : 'Editar Categoria'; ?></h1>
    <div class="btn-toolbar mb-2">
        <a href="categories.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i> Voltar
        </a>
    </div>
</div>

<form method="post">
    <div class="row justify-content-center">
        <div class="col-md-8 col-lg-6">
            <div class="card mb-4">
                <div class="card-header">Informações da Categoria</div>
                <div class="card-body">
                    <div class="mb-3">
                        <label for="name" class="form-label">Nome da Categoria</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($current_category['name'] ?? ''); ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="description" class="form-label">Descrição</label>
                        <textarea class="form-control" id="description" name="description" rows="3"><?php echo htmlspecialchars($current_category['description'] ?? ''); ?></textarea>
                    </div>
                </div>
            </div>
            
            <div class="d-grid">
                <button type="submit" class="btn btn-primary btn-lg">
                    <i class="fas fa-save me-2"></i>Salvar Categoria
                </button>
            </div>
        </div>
    </div>
</form>
<?php endif; ?>

<?php
db_close($conn);
require_once 'includes/footer.php';
?>
