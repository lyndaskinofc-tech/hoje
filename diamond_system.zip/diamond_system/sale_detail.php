<?php
require_once 'config/config.php';
require_once 'classes/Sale.php';

require_login();

$conn = db_connect();
$sale_obj = new Sale($conn);

$id = $_GET['id'] ?? 0;
$sale = $sale_obj->getById($id);

if (!$sale) {
    display_error('Venda não encontrada.');
    redirect(BASE_URL . 'sales.php');
}

$page_title = 'Detalhes da Venda #' . $id;

require_once 'includes/header.php';
require_once 'includes/sidebar.php';
?>

<div class="d-flex justify-content-between flex-wrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><i class="fas fa-receipt me-2"></i>Venda #<?php echo $sale['id']; ?></h1>
    <div class="btn-toolbar mb-2">
        <a href="sales.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i> Voltar
        </a>
    </div>
</div>

<div class="row g-4">
    <div class="col-lg-8">
        <div class="card mb-4">
            <div class="card-header">Itens da Venda</div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Produto</th>
                                <th>Preço Unitário</th>
                                <th>Quantidade</th>
                                <th>Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($sale['items'] as $item): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                                <td><?php echo format_money($item['price']); ?></td>
                                <td><?php echo $item['quantity']; ?></td>
                                <td><?php echo format_money($item['subtotal']); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="3" class="text-end"><strong>Total:</strong></td>
                                <td><strong><?php echo format_money($sale['total']); ?></strong></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-lg-4">
        <div class="card">
            <div class="card-header">Informações da Venda</div>
            <div class="card-body">
                <div class="mb-3">
                    <strong>Data:</strong><br>
                    <?php echo format_date($sale['sale_date']); ?>
                </div>
                
                <div class="mb-3">
                    <strong>Cliente:</strong><br>
                    <?php echo htmlspecialchars($sale['client_name'] ?: 'Não registrado'); ?>
                </div>
                
                <div class="mb-3">
                    <strong>Vendedor:</strong><br>
                    <?php echo htmlspecialchars($sale['user_name']); ?>
                </div>
                
                <div class="mb-3">
                    <strong>Forma de Pagamento:</strong><br>
                    <?php echo htmlspecialchars($sale['payment_method']); ?>
                </div>
                
                <div class="mb-3">
                    <strong>Status:</strong><br>
                    <?php if ($sale['status'] == 'concluída'): ?>
                        <span class="badge bg-success">Concluída</span>
                    <?php elseif ($sale['status'] == 'cancelada'): ?>
                        <span class="badge bg-danger">Cancelada</span>
                    <?php else: ?>
                        <span class="badge bg-warning">Pendente</span>
                    <?php endif; ?>
                </div>
                
                <?php if ($sale['notes']): ?>
                <div class="mb-3">
                    <strong>Observações:</strong><br>
                    <?php echo nl2br(htmlspecialchars($sale['notes'])); ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php
db_close($conn);
require_once 'includes/footer.php';
?>
